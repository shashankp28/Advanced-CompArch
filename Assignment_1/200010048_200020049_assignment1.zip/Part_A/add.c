#include<stdio.h>

float add(float a, float b){
    return a+b;
}

int main()
{
    float a=12389.5, b=9871, c, d, e, f, g, h; 
    c = add(a,b);
    d = a - b;
    d = a - b;
    e = a * b;
    f = a / b;
    g = f + a;
    h = f + c;
    return 0;
}
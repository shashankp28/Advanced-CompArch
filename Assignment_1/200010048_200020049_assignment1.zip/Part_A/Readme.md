Notes :

opcodemix.so - gives static & dynamic instructions and its count
insmix.so - gives entire information of instructions and its counts
jumpmix.so - contains details about all calls & branches taken
ldstmix.so - load/store
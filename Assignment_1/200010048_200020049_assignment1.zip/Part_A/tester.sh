~/pin-3.28-98749-g6643ecee5-gcc-linux/pin -t ~/pin-3.28-98749-g6643ecee5-gcc-linux/source/tools/$1/obj-intel64/$2 -- $3

# python3 getDynamic.py opcodemix.out inscount.out ldstmix.out